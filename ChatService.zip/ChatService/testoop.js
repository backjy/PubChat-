/**
 * Created by mimi on 15/4/21.
 */


console.log('began test ========================')
var oop = function (a) {
    this.name = a;
};

oop.prototype.showName = function () {
    console.log(this.name)
}

var oppa = new  oop('test A')
var oppb = new  oop('test b')
var oppc = new  oop('test c')
oppa.showName();
oppb.showName();
oppc.showName();

console.log('end test ========================')