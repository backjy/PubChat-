/**
 * Created by mimi on 15/4/17.
 */

var UserInfo = require( "./userInfo").UserInfo;


var UserInfoManager = function() {
    this.users = {}
};

UserInfoManager.prototype.createNewUser = function(sSocketUID, sUserNickName, sbriefIntroduction, sIp, iPort)
{
    var userInfo = new UserInfo(sSocketUID, sUserNickName, sbriefIntroduction, sIp, iPort);
    this.users[userInfo.userUID] = userInfo;
    return userInfo;
}

UserInfoManager.prototype.getUserInfoByUID = function(sUserUID)
{
    var userInfo = this.users[sUserUID]
    if( userInfo )
    {
        return userInfo;
    }
    return null
}

UserInfoManager.prototype.offline = function (userUID)
{
    delete this.users[userUID]
}

module.exports = {
    UserInfoManager:UserInfoManager
};