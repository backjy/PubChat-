/**
 * Created by mimi on 15/4/17.
 */

var SocketInfo = require('./socketInfo')

var socketInfoManager = function(){
    this.sockets = {}
}

/*
socket 连接进来
@param pService chat服务器
@param socket的 uuid
@param socket本身
 */
socketInfoManager.prototype.socketConnectIn = function(pService, sSocketUID, pSocket)
{
    if( this.sockets[sSocketUID])
    {
        this.socketClose(sSocketUID)
    }
    var socketInfo = SocketInfo.createSocketInfo(pService, sSocketUID, pSocket)
    this.sockets[sSocketUID] = socketInfo
}

/*
socket 收到数据
@param socket 的uuid
@param pData 收到的数据
 */
socketInfoManager.prototype.socketReciveData = function( sSocketUID, pData)
{
    var socketInfo = this.sockets[sSocketUID]
    if(socketInfo)
    {
        socketInfo.recived(pData)
    }
}

/*
socket 关闭
@param sSocketUID socekt 的唯一id
 */
socketInfoManager.prototype.socketClose = function( sSocketUID)
{
    var socketInfo = this.sockets[sSocketUID]
    if(socketInfo)
    {
        socketInfo.close()
        delete this.sockets[sSocketUID]
    }
}

socketInfoManager.prototype.getSocketInfoByUID = function (sSocketUID) {
    var socketInfo = this.sockets[sSocketUID]
    if(socketInfo)
    {
        return socketInfo
    }
    return null
}

var manager = new socketInfoManager()

module.exports = {
    manager:manager
}