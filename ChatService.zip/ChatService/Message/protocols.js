/**
 * Created by mimi on 15/4/17.
 */

var msg_protocols = {}

msg_protocols.init          = 'init'        //  初始化消息协议
msg_protocols.login         = 'login'       //  登陆消息协议
msg_protocols.onlineUserList   = 'onlineUserList' //  在线用户协议
msg_protocols.groupOnlines  = 'groupOnlines'//  在线群组消息协议
msg_protocols.msgSTC        = 'msgSTC'      //  服务器通知到client 的消息协议
msg_protocols.msgCTS        = 'msgCTS'      //  client 到服务器的消息协议

module.exports = {
    msg_protocols:msg_protocols
}

