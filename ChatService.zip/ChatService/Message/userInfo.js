/**
 * Created by mimi on 15/4/17.
 */

/*
 * 创建一个用户信息
 * @param sSocketUID socket 的唯一id
 * @param sUserNickName 用户昵称
 * @param sbriefIntroduction 用户简介
 * @param sIp
 * @param iPort
 */

var userInfo = function (sSocketUID, sUserNickName, sbriefIntroduction, sIp, iPort)
{
    this.socketUID = sSocketUID;
    this.userNickName = sUserNickName;
    this.userUID = sSocketUID;
    this.briefIntroduction = sbriefIntroduction;
    this.fromIp = sIp;
    this.fromPort = iPort;
}

module.exports = {
    UserInfo:userInfo
}
