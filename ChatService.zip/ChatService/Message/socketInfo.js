/**
 * Created by mimi on 15/4/16.
 */
var ExBuffer = require('ExBuffer')
/*
 * 创建一个和socket 关联的 socketinfo 方便管理
 * @param pService chat服务器
 * @param sSocketUID socket uuid
 * @param pSocket socket
 */
var socketInfo = function(pService, sSocketUID, pSocket)
{
    this.socketUID   = sSocketUID;// socket uid
    this.userUID     = ''; // user uid
    this.groupUIDs   = [];// groups
    this.socket      = pSocket;// socket
    this.exBuffer    = new ExBuffer().uint32Head().littleEndian();
    this.service     = pService;
    var self         = this;
    this.exBuffer.on('data',function(data) {

        // base 64 解码
        //console.log('recived:'+ data.toString())
        var nData = new Buffer(data.toString(), 'base64')
        //console.log('recived:'+ nData.toString())
        self.service.logicMapping.runLogic(nData,self);
    });
}
/*
 * @param pData 收到的数据
 */
socketInfo.prototype.recived = function(pData)
{
    this.exBuffer.put(pData)
}

socketInfo.prototype.writeData = function ( pData)
{
    console.log('\t\tshuld write:',pData.length,'bytes')
    var base64 = new Buffer(pData).toString('base64')
    var headBuffer = new Buffer(4)
    headBuffer.writeInt32LE(base64.length)
    this.socket.write(headBuffer)
    var bodyBuffer = new Buffer(base64.length)
    bodyBuffer.write(base64)
    this.socket.write(bodyBuffer)
}

/*
 * @param pService chat服务器
 */
socketInfo.prototype.close = function () {
    this.service.userInfoManager.offline(this.userUID)
}

/*
 *
 * @param pService chat服务器
 */
function createSocketInfo(pService, sSocketUID, pSocket)
{
    return new socketInfo(pService, sSocketUID, pSocket);
}

module.exports = {
    createSocketInfo:createSocketInfo
}