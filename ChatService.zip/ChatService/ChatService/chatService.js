/**
 * Created by mimi on 15/4/17.
 */


var tcp = require('../Base/tcp')
var socketInfoManager = require('../Message/socketInfoManager')
var UserInfoManager = require('../Message/userInfoManager').UserInfoManager
var LogicMapping = require('../Logic/LogicMapping').LogicMapping

function createChatService( iPort) {
    var service = {}
    service.socketInfoManager = socketInfoManager.manager;
    service.userInfoManager = new UserInfoManager();
    service.logicMapping = new LogicMapping();
    service.sv = tcp.createServers( iPort, initFunction, connectFunction, recivedFunction, closeFunction)
    // 初始化成功函数
    function initFunction()
    {
        console.log('service init!')
        console.log(service.sv.address())
    }
    // 连接函数
    function connectFunction( sSocketUID, pSocket)
    {
        console.log('get in:'+ pSocket.remoteAddress + ' : ' + pSocket.remoteAddress + ' : ' + pSocket.remotePort)
        service.socketInfoManager.socketConnectIn(service, sSocketUID, pSocket)
    }
    // 收包函数
    function recivedFunction( sSocketUID, pData)
    {
        service.socketInfoManager.socketReciveData( sSocketUID, pData)
    }
    // 关闭函数
    function closeFunction( sSocketUID)
    {
        service.socketInfoManager.socketClose( sSocketUID)
        console.log( sSocketUID + '  closed!')
    }

    return service
}

module.exports = {
    createChatService:createChatService
}
