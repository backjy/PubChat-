/**
 * Created by mimi on 15/4/16.
 */


//require('./testoop')


var service = require("./ChatService/chatService");

var serv1 = service.createChatService(8081)
