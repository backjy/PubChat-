/**
 * Created by mimi on 15/4/21.
 */

var LoginLogic = function () {
    console.log( 'init login logic successed!');
};

LoginLogic.prototype.handleProtocol = function (content, socketInfo)
{
    console.log('into login logic handle!');
    //console.log(content);
    var putData      = {};
    putData.protocol = content.protocol;

    var userInfo  = socketInfo.service.userInfoManager.createNewUser(socketInfo.socketUID,
                                                                     content.userNickName,
                                                                     content.briefIntroduction,
                                                                     socketInfo.socket.remoteAddress,
                                                                     socketInfo.socket.remotePort);
    if(userInfo)
    {
        putData.state    = "1";
        putData.msg      = 'accessed new user!';
    }
    else
    {
        putData.state    = "0";
        putData.msg      = 'create new user failed!';
    }

    putData.userID   = userInfo.userUID;
    socketInfo.userUID = userInfo.userUID
    userInfo = null
    socketInfo.writeData(JSON.stringify(putData))
    console.log('\tResponse user login!');
};

exports.LoginLogic = LoginLogic;