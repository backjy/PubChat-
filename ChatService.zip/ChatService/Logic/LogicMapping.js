/**
 * Created by mimi on 15/4/21.
 */

var protocols = require('../Message/protocols').msg_protocols;

var LoginLogic = require('./LoginLogic').LoginLogic;

var OnlineUsersLogic = require('./OnlineUsersLogic').OnlineUsersLogic

var MessageLogic = require('./MessageLogic').MessageLogic

var LogicMapping = function()
{
    this.logicMapping = {}
    this.logicMapping[protocols.login] = new LoginLogic();
    this.logicMapping[protocols.onlineUserList] = new OnlineUsersLogic();
    this.logicMapping[protocols.msgCTS] = new MessageLogic();
};

LogicMapping.prototype.runLogic = function (contents, socketInfo) {
    var jsonValue = JSON.parse(contents);
    if( this.logicMapping[jsonValue.protocol] != null)
    {
        var logic = this.logicMapping[jsonValue.protocol];
        logic.handleProtocol(jsonValue,socketInfo);
    }
    else
    {
        console.log('mapping no protocol with:'+contents)
    }
};

exports.LogicMapping = LogicMapping;
