/**
 * Created by mimi on 15/4/28.
 */

var protocols = require('../Message/protocols').msg_protocols

var MessageLogic = function () {

};

MessageLogic.prototype.handleProtocol = function (content, socketInfo)
{
    console.log('handle message logic!')
    /* contentKeys
    sendUID     发送人的uid
    toUID       接受人得uid
    msgType     消息类型，
    msgContent  消息内容
    msgID       消息回调
    */
    var response = {}
    response.msg = '';
    response.state = '0';
    response.msgID = content.msgID
    var sendUserInfo = socketInfo.service.userInfoManager.getUserInfoByUID(content.sendUID) ;
    var reciveUserInfo = socketInfo.service.userInfoManager.getUserInfoByUID(content.toUID) ;
    if (reciveUserInfo)
    {
        if( content.chatType != 'group')
        {

            console.log('\t\tpost message to recive client began!')
            /*
             msgContent;//消息内容
             msgType;// 消息类型
             msgFrom;// 消息来源
             */
            var postPackage = {};
            postPackage.protocol = protocols.msgSTC;
            postPackage.msgContent = content.msgContent;
            postPackage.msgType = content.msgType;
            postPackage.msgFrom = content.sendUID;
            postPackage.msgFNick = sendUserInfo.userNickName;
            postPackage.chatType = content.chatType;
            var reciveSocketInfo = socketInfo.service.socketInfoManager.getSocketInfoByUID(reciveUserInfo.socketUID);
            if( reciveSocketInfo)
            {
                response.state = '1';
                response.msg = "successed!";
                reciveSocketInfo.writeData(JSON.stringify(postPackage));
                console.log('\t\tpost message to recive client successed!');
            }
            else
            {
                response.msg = "no socket info!";
                console.log('\t\tpost message to recive client failed!');
            }
        }
    }
    else
    {
        response.msg = 'user not exit,or user offline!';
    }
    response.protocol = content.protocol;
    socketInfo.writeData(JSON.stringify(response))
    console.log('\rResponse message logic!')
}

exports.MessageLogic = MessageLogic
