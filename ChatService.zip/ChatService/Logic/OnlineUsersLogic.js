/**
 * Created by mimi on 15/4/27.
 */

var OnlineUsersLogic = function () {
}

OnlineUsersLogic.prototype.handleProtocol = function (content, socketInfo)
{
    console.log('into online user logic!');
    //var respomseData = Json.stringify(socketInfo.service.userInfoManager.users);
    var response = {}
    response.onlineUsers = socketInfo.service.userInfoManager.users;
    response.state = '1'
    response.msg = 'successed!';
    response.protocol = content.protocol;
    socketInfo.writeData(JSON.stringify(response))

    console.log('\tresponse cliend onlineUserList!');
}


exports.OnlineUsersLogic = OnlineUsersLogic;