
var net = require('net')
var netEvents = require('./netEvents')
var crypto = require('crypto')

/*
 * 创建一个服务器监听
 * @param iPort 启动端口号
 * @param funInit 启动成功回调函数
 * @param funConnect(socketuuid,socket) 服务器发生连接的回调函数
 * @param funRecive(socketuuid,data) socket 收到数据的函数
 * @param funClose(socketuuid) socket 断开连接的函数
 */
function createServers(iPort, funInit, funConnect, funRecive, funClose)
{
    var server = net.createServer()

    server.listen(iPort);

    server.on(netEvents.event_tcp_listening,function()
    {
        funInit();
    });

    server.on(netEvents.event_tcp_connection,function(pSocket)
    {
        var socketUUID = getSocketUUID(pSocket,server.connections)
        pSocket.on(netEvents.event_socket_data,function(data)
        {
            funRecive( socketUUID, data);
        });

        pSocket.on(netEvents.event_socket_close,function()
        {
            funClose(socketUUID);
            socketUUID = null
        });

        pSocket.on(netEvents.event_socket_error,function(error)
        {
            console.log('Socket Error:' + error);
            pSocket.end();
        });
        funConnect(socketUUID, pSocket);
    });

    return server;
}

/*
 * 发送一段内容给某个socket
 * @param pSocket 发送的数据的socket
 * @param strBuffer 发送的字符串内容
 */
function sendBuffer(pSocket, strBuffer)
{
    pSocket.write(strBuffer);
}

/*
 * 关闭服务器
 * 关闭的 servers
 */
function closeServer(server)
{

    server.close();
}

/*
 * 创建一个 tcp ip client
 * @param sHost 主机地址
 * @param iPort 主机端口
 * @param funInit 初始化成功
 * @param funRecive 收到包
 * @param funClose 断开连接
 */
function createClient( sHost, iPort, funInit, funRecive, funClose)
{
    if ( sHost == "")
    {
        sHost = '127.0.0.1'
        console.log('tcp warnning: socket will connect to local host！')
    }
    if ( iPort <= 0)
    {
        console.log('tcp error: create client failed, case port less equal zero！')
        return
    }

    var pSocket = net.connect( iPort, sHost, function() {
        if (funInit != null)
            funInit();
    });

    pSocket.on(netEvents.event_socket_data, function(data){

    });

    pSocket.on(netEvents.event_socket_error, function(error){
        console.log('socket client error:  '+error)
        pSocket.end();
    });

    pSocket.on(netEvents.event_socket_close,function(){
        console.log('socket client:Connection closed');
        funClose();
    });

    return pSocket
}

/*
 *   通过socket 的remoteAddress + localAddress + remotePort 计算md5 码
 *   @param pSocket 需要计算的socket
 */
function getSocketUUID(pSocket,index)
{
    var str = pSocket.remoteAddress + pSocket.remotePort + index;
    var md5sum = crypto.createHash('md5');
    md5sum.update(str);
    str = md5sum.digest('hex');
    return str;
}

//export
module.exports = {
    createServers:createServers,
    sendBuffer:sendBuffer,
    closeServer:closeServer,
    createClient:createClient,
    getSocketUUID:getSocketUUID
}