/**
 * Created by mimi on 15/4/16.
 */


// tcp 有连接时会触发改event
var event_tcp_connection = 'connection'
// tcp 监听成功时触发该event
var event_tcp_listening  = 'listening'
// tcp
var event_tcp_error      = 'error'


//  socket 连接发生错误时的 event
var event_socket_error  = 'error'
//  socket 关闭时的 event
var event_socket_close  = 'close'
//  event 进入数据时的 event
var event_socket_data   = 'data'


//  导出可用名
module.exports = {
    event_tcp_connection:event_tcp_connection,
    event_tcp_listening:event_tcp_listening,
    event_socket_error:event_socket_error,
    event_socket_close:event_socket_close,
    event_socket_data:event_socket_data
}

/*
 * async
 * cheerio
 * eventproxy
 * ExBuffer
 * express
 * jade
 * list
 * superagent
 * utility
 */