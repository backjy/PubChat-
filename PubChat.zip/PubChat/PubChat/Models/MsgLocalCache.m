//
//  MsgLocalCache.m
//  PubChat
//
//  Created by mimi on 15/4/30.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "MsgLocalCache.h"

#import "GTMBase64.h"

@interface MsgLocalCache()
{
    NSString* savePath;
}

@end

@implementation MsgLocalCache

+(MsgLocalCache*) defaultCache
{
    static MsgLocalCache* s_defaultLocalCache = nil;
    @synchronized(self)
    {
        if (!s_defaultLocalCache)
        {
            s_defaultLocalCache = [MsgLocalCache new];
        }
    }
    return s_defaultLocalCache;
}

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        savePath = [NSString stringWithFormat:@"%@/%@",documentsDirectory,@"msgData"];
        NSDictionary* cacheData = nil;
        if ([[NSFileManager defaultManager] fileExistsAtPath:savePath])
        {
            NSData* fileData = [[NSFileManager defaultManager] contentsAtPath:savePath];
            if (fileData)
            {
                NSData* base64Data = [GTMBase64 decodeData:fileData];
                id tmp = [NSKeyedUnarchiver unarchiveObjectWithData:base64Data];
                if ([tmp isKindOfClass:[NSDictionary class]])
                {
                    cacheData = tmp;
                }
                else
                {
                    NSError* error;
                    BOOL success = [[NSFileManager defaultManager] removeItemAtPath:savePath error:&error];
                    if (!success) {
                        NSLog(@"Error removing file at path: %@", error.localizedDescription);
                    }
                }
            }
        }
        NSInteger count = cacheData? cacheData.count:100;
        _cacheDic = [NSMutableDictionary dictionaryWithCapacity:count];
        if (cacheData)
        {
            for (NSString* key in cacheData)
            {
                NSArray* array = [cacheData objectForKey:key];
                if (array)
                {
                    [_cacheDic setValue:array.mutableCopy forKey:key];
                }
            }
        }
        
    }
    return self;
}


-(void) saveMsg:(NSArray*) msgs key:(NSString*) key
{
    if (!msgs || !key)
    {
        NSLog(@"save message failed!");
        return;
    }
    [_cacheDic setValue:msgs forKey:key];
}

-(NSMutableArray*) getMsgByKey:(NSString*) key
{
    NSMutableArray* msgs = [_cacheDic valueForKey:key];
    if (!msgs)
    {
        msgs = [NSMutableArray arrayWithCapacity:10];
        [self saveMsg:msgs key:key];
    }
    return msgs;
}

-(void) cleanCache
{
    [_cacheDic removeAllObjects];
    [self saveCache];
}

-(void) saveCache
{
    NSData *saveData = [NSKeyedArchiver archivedDataWithRootObject:_cacheDic];
    if (saveData)
    {
        NSData* base64Data = [GTMBase64 encodeData:saveData];
        if (base64Data && [base64Data writeToFile:savePath atomically:YES])
        {
            NSLog(@"save local message cache successed!");
        }
        else
        {
            NSLog(@"save local message cache failed at in!");
        }
    }
    else
    {
        NSLog(@"save local message cache failed at out!");
    }
}

@end
