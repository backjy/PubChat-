//
//  UserInfo.m
//  PubChat
//
//  Created by mimi on 15/4/27.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "UserInfo.h"

@implementation UserInfo

+(UserInfo*) currentUser
{
    static UserInfo* s_userInfo = nil;
    @synchronized(self)
    {
        if (!s_userInfo)
        {
            s_userInfo = [UserInfo new];
        }
    }
    return s_userInfo;
}

@end
