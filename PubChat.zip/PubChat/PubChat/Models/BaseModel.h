//
//  BaseModel.h
//  WYHK
//
//  Created by duck on 15/1/13.
//  Copyright (c) 2015年 kratos. All rights reserved.
//

#import <Foundation/Foundation.h>

//此类只能在非arc下使用，需要在ARC中BuildPhase -> Compile Sources加入flag -fno-objc-arc
@interface BaseModel : NSObject
- (id)initWithDataDic:(NSDictionary*)data;
- (NSDictionary*)attributeMapDictionary;
- (void)setAttributes:(NSDictionary*)dataDic;
- (NSString *)customDescription;
- (NSString *)description;
@end
