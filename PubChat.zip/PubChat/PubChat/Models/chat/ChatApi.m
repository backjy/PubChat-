//
//  ChatApi.m
//  PubChat
//
//  Created by mimi on 15/4/28.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "ChatApi.h"

#import "SocketClient.h"

@implementation ChatApi

static NSInteger messageCounter = 0;

/**
 *  @author mimi, 15-04-28 15:04:26
 *
 *  发送一个消息
 *
 *  @param sendUID    发送人的uid
 *  @param toUID      接受人得uid
 *  @param msgType    消息类型，
 *  @param msgContent 消息内容
 *  @param response   消息回调
 *
 *  @return 消息的id
 */
+(NSInteger) sendMessageFrom:(NSString*) sendUID
                          to:(NSString*) toUID
                 messageType:(NSString*) msgType
                    chatType:(NSString*) chatType
              messageContent:(NSString*) msgContent
                    response:(ChatResponseBlock) response
{
    messageCounter++;
    
    NSDictionary* sendDic = @{
                              @"protocol":@"msgCTS",
                              @"sendUID":sendUID,
                              @"toUID":toUID,
                              @"msgType":msgType,
                              @"msgContent":msgContent,
                              @"chatType":chatType,
                              @"msgID":[NSNumber numberWithInteger:messageCounter].stringValue
                              };
    
    NSData* senData = [NSJSONSerialization dataWithJSONObject:sendDic options:NSJSONWritingPrettyPrinted error:nil];
    [[SocketClient currentClient] sendMessage:senData protocol:@"msgCTS" resultBlock:^(NSDictionary *data, NSString *errMsg)
     {
         if (data)
         {
             ChatPostResponseModel* repModel = [[ChatPostResponseModel alloc] initWithDataDic:data];
             response(repModel,repModel.msg);
         }
         else
         {
             response(nil, errMsg);
         }
     }];
    
    return messageCounter;
}

@end
