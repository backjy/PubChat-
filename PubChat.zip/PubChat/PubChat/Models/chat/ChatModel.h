//
//  ChatModel.h
//  PubChat
//
//  Created by mimi on 15/4/28.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BaseModel.h"

/**
 *  @author mimi, 15-04-28 14:04:32
 *
 *  主动发生消息的回复
 */

@interface ChatPostResponseModel : BaseModel
@property(strong,nonatomic) NSString* msgID;//消息id
@property(strong,nonatomic) NSString* state;// 消息状态
@property(strong,nonatomic) NSString* msg;// 消息文字状态
@end

@interface ChatAutoReciveModel : BaseModel
@property(strong,nonatomic) NSString* msgContent;//消息内容
@property(strong,nonatomic) NSString* msgType;// 消息类型
@property(strong,nonatomic) NSString* msgFrom;// 消息来源
@property(strong,nonatomic) NSString* msgFNick;// 消息来源
@property(strong,nonatomic) NSString* chatType;//聊天类型
@end


/**
 *  @author mimi, 15-04-29 14:04:19
 *
 *  聊天界面的数据类型
 */
static NSString* const sChatingMsgSelfCellIdentify = @"sChatingMsgSelfCellIdentify";
static NSString* const sChatingMsgTargetCellIdentify = @"sChatingMsgTargetCellIdentify";

static NSString* const sNewChatEvent = @"sNewChatEvent";// 新的聊天记录
static NSString* const sNewMessageEvent = @"sNewMessageEvent";// 新的聊天消息

@interface ChatMessageModel : NSObject<NSCoding>
@property(strong,nonatomic) NSString* msgSender;// 消息发送者
@property(strong,nonatomic) NSString* msgSenderNick;// 消息发送者昵称
@property(strong,nonatomic) NSString* msgContent;// 消息内容
@property(strong,nonatomic) NSString* msgType;// 消息类型
@property(strong,nonatomic) NSString* chatType;// 消息类型
@property(assign,nonatomic) NSInteger msgID;// 消息id
@property(assign,nonatomic) NSInteger msgState;// 消息状态

@property(assign,nonatomic) BOOL isSelf;

+(ChatMessageModel*) createMessageWith:(ChatAutoReciveModel*) model;


+(ChatMessageModel*) createMessageWithSend:(NSString*) msgContent
                                   msgType:(NSString*) msgType
                                  chatType:(NSString*) chatType
                                 msgSender:(NSString*) msgSender
                                     msgID:(NSInteger) msgID
                                    isSelf:(BOOL) isSelf;
/**
 *  @author mimi, 15-04-29 15:04:05
 *
 *  获取label 的动态高度
 *
 *  @param width     可显示区域的高
 *  @param orgHeight label 本来的高度
 *
 *  @return 高度差
 */
-(CGFloat)getMessageContentHeight:(CGFloat)width orgHeight:(CGFloat) orgHeight UIFont:(UIFont*) font;
@end

/**
 *  @author mimi, 15-04-30 13:04:34
 *
 *  聊天列表中 cell 的数据模型
 */
@interface ChatEventModel : NSObject
@property(strong,nonatomic) NSString* msgSender;// 消息发送者
@property(strong,nonatomic) NSString* msgSenderNick;// 消息发送者昵称
@property(strong,nonatomic) NSString* chatType;// 聊天类型 群聊天 个人聊天
@end
