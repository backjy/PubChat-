//
//  ChatApi.h
//  PubChat
//
//  Created by mimi on 15/4/28.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "ChatModel.h"

typedef void (^ChatResponseBlock)(ChatPostResponseModel* model,NSString* msg);

@interface ChatApi : NSObject

/**
 *  @author mimi, 15-04-28 15:04:26
 *
 *  发送一个消息
 *
 *  @param sendUID    发送人的uid
 *  @param toUID      接受人得uid
 *  @param msgType    消息类型，
 *  @param msgContent 消息内容
 *  @param response   消息回调
 *
 *  @return 消息的id
 */
+(NSInteger) sendMessageFrom:(NSString*) sendUID
                          to:(NSString*) toUID
                 messageType:(NSString*) msgType
                    chatType:(NSString*) chatType
              messageContent:(NSString*) msgContent
                    response:(ChatResponseBlock) response;

@end
