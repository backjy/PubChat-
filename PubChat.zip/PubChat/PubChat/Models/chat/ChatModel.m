//
//  ChatModel.m
//  PubChat
//
//  Created by mimi on 15/4/28.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "ChatModel.h"

#import "NSString+Size.h"

@implementation ChatPostResponseModel
-(NSDictionary *)attributeMapDictionary
{
    return @{
             @"msgID":@"msgID",//消息id
             @"state":@"state",// 消息状态
             @"msg":@"msg"// 消息文字状态
             };
}
@end

@implementation ChatAutoReciveModel

-(NSDictionary *)attributeMapDictionary
{
    return @{
             @"msgContent":@"msgContent",//消息内容
             @"msgType":@"msgType",// 消息类型
             @"msgFrom":@"msgFrom",// 消息来源
             @"msgFNick":@"msgFNick",
             @"chatType":@"chatType"
             };
}
@end

@implementation ChatMessageModel


+(ChatMessageModel*) createMessageWith:(ChatAutoReciveModel*) model
{
    ChatMessageModel* pRet = [ChatMessageModel new];
    pRet.msgContent = model.msgContent;
    pRet.msgSender = model.msgFrom;
    pRet.msgSenderNick = model.msgFNick;
    pRet.msgType = model.msgType;
    pRet.chatType = model.chatType;
    pRet.msgState = 1;
    pRet.isSelf = NO;
//    pRet.msgType
    return pRet;
}

+(ChatMessageModel*) createMessageWithSend:(NSString*) msgContent
                                   msgType:(NSString*) msgType
                                  chatType:(NSString*) chatType
                                 msgSender:(NSString*) msgSender
                                     msgID:(NSInteger) msgID
                                    isSelf:(BOOL) isSelf
{
    ChatMessageModel* pRet = [ChatMessageModel new];
    pRet.msgContent = msgContent;
    pRet.msgSender = msgSender;
    pRet.msgType = msgType;
    pRet.chatType = chatType;
    pRet.msgID = msgID;
    pRet.isSelf = isSelf;
    return pRet;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _msgContent = @"";
        _msgSender = @"";
        _msgID = -1;
        _msgType = @"";
        _chatType = @"";
        _msgSenderNick = @"";
        _msgState = 0;
        _isSelf = NO;
    }
    return self;
}

/**
 *  @author mimi, 15-04-29 15:04:05
 *
 *  获取label 的动态高度
 *
 *  @param width     可显示区域的高
 *  @param orgHeight label 本来的高度
 *
 *  @return 高度差
 */
-(CGFloat)getMessageContentHeight:(CGFloat)width orgHeight:(CGFloat) orgHeight UIFont:(UIFont *)font
{
    CGSize newSize = [self.msgContent calculateSize:CGSizeMake(width, 512) font:font];
    CGFloat newHeight = newSize.height - orgHeight;
    if (newHeight < 0)
    {
        return 0;
    }
    return newHeight;
}

//NSString* msgSender;// 消息发送者
//NSString* msgSenderNick;// 消息发送者
//NSString* msgContent;// 消息内容
//NSString* msgType;// 消息类型
//NSInteger msgID;// 消息id
//NSInteger msgState;// 消息状态
//BOOL isSelf;
- (void)encodeWithCoder:(NSCoder *)aCoder
{
    [aCoder encodeObject:self.msgSender forKey:@"msgSender"];
    [aCoder encodeObject:self.msgSenderNick forKey:@"msgSenderNick"];
    [aCoder encodeObject:self.msgContent forKey:@"msgContent"];
    [aCoder encodeObject:self.msgType forKey:@"msgType"];
    [aCoder encodeInteger:self.msgID forKey:@"msgID"];
    [aCoder encodeInteger:self.msgState forKey:@"msgState"];
    [aCoder encodeBool:self.isSelf forKey:@"isSelf"];
}

- (id)initWithCoder:(NSCoder *)aDecoder
{
    if (self = [super init]) {
        self.msgSender = [aDecoder decodeObjectForKey:@"msgSender"];
        self.msgSenderNick = [aDecoder decodeObjectForKey:@"msgSenderNick"];
        self.msgContent = [aDecoder decodeObjectForKey:@"msgContent"];
        self.msgType = [aDecoder decodeObjectForKey:@"msgType"];
        self.msgID = [aDecoder decodeIntegerForKey:@"msgID"];
        self.msgState = [aDecoder decodeIntegerForKey:@"msgState"];
        self.isSelf = [aDecoder decodeBoolForKey:@"isSelf"];
    }
    return self;
}

@end



/**
 *  @author mimi, 15-04-30 13:04:34
 *
 *  聊天列表中 cell 的数据模型
 */
@implementation  ChatEventModel
- (instancetype)init
{
    self = [super init];
    if (self) {
        _msgSender = @"";// 消息发送者
        _msgSenderNick = @"";// 消息发送者昵称
        _chatType = @"";// 聊天类型 群聊天 个人聊天
    }
    return self;
}
@end
