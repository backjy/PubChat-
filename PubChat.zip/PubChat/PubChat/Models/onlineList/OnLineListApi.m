//
//  OnLineListApi.m
//  PubChat
//
//  Created by mimi on 15/4/27.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "OnLineListApi.h"

#import "SocketClient.h"

@implementation OnLineListApi


/**
 *  @author mimi, 15-04-27 11:04:59
 *
 *  获取在线用户列表
 *
 *  @param useruuid    登陆用户的uuid
 *  @param resultBlock 回调接过
 */
+(void) getOnlineUserList:(NSString*) userUID
              resultBlock:(OnlineUserBlock) resultBlock
{
    NSDictionary* sendDic = @{
                               @"protocol":@"onlineUserList",
                               @"userUID":userUID
                               };
    NSData* senData = [NSJSONSerialization dataWithJSONObject:sendDic options:NSJSONWritingPrettyPrinted error:nil];
    [[SocketClient currentClient] sendMessage:senData protocol:@"onlineUserList" resultBlock:^(NSDictionary *data, NSString *errMsg)
     {
         if (data)
         {
             OnlineUserListModel* repModel = [[OnlineUserListModel alloc] initWithDataDic:data];
             resultBlock(repModel,repModel.msg);
         }
         else
         {
             resultBlock(nil, errMsg);
         }
     }];
}

/**
 *  @author mimi, 15-04-27 15:04:08
 *
 *  获取在线组列表
 *
 *  @param userUID      登陆用户的uuid
 *  @param resultBlock  回调结果
 */
+(void) getOnlineGroupList:(NSString*) userUID
               resultBlock:(OnlineGroupBlock) resultBlock
{
    NSDictionary* sendDic = @{
                              @"protocol":@"onlineGroupList",
                              @"userUID":userUID
                              };
    NSData* senData = [NSJSONSerialization dataWithJSONObject:sendDic options:NSJSONWritingPrettyPrinted error:nil];
    [[SocketClient currentClient] sendMessage:senData protocol:@"onlineGroupList" resultBlock:^(NSDictionary *data, NSString *errMsg)
     {
         if (data)
         {
             OnlineGroupListModel* repModel = [[OnlineGroupListModel alloc] initWithDataDic:data];
             resultBlock(repModel,repModel.msg);
         }
         else
         {
             resultBlock(nil, errMsg);
         }
     }];
}

@end
