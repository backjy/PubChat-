//
//  OnlineListModel.m
//  PubChat
//
//  Created by mimi on 15/4/27.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "OnlineListModel.h"


/**
 *  @author mimi, 15-04-27 11:04:14
 *
 *  在线用户item
 */
@implementation OnlineUserItem


-(NSDictionary *)attributeMapDictionary
{
    return @{
             @"nickName":@"userNickName",// 昵称
             @"briefIntroduction":@"briefIntroduction",//简介
             @"userID":@"userID"// 唯一id
             };
}

@end

/**
 *  @author mimi, 15-04-27 11:04:07
 *
 *  在线组model
 */
@implementation OnlineUserListModel

-(NSDictionary *)attributeMapDictionary
{
    return @{
             @"state":@"state",
             @"msg":@"msg",
             @"onlineUsers":@"onlineUsers"
             };
}

-(void) setOnlineUsers:(NSDictionary *)onlineUsers
{
    NSMutableDictionary* tmp = [NSMutableDictionary dictionaryWithCapacity:onlineUsers.count];
    for (NSString* key in onlineUsers)
    {
        id value = [onlineUsers objectForKey:key];
        if ([value isKindOfClass:[NSDictionary class]])
        {
            OnlineUserItem* item = [[OnlineUserItem alloc] initWithDataDic:value];
            [tmp setValue:item forKey:key];
            item.userID = key;
        }
    }
    _onlineUsers = tmp;
}

@end



/**
 *  @author mimi, 15-04-27 11:04:07
 *
 *  在线组model
 */
@implementation OnlineGroupItem

-(NSDictionary *)attributeMapDictionary
{
    return @{
             @"groupName":@"groupName",// 昵称
             @"groupIntroduction":@"groupIntroduction",//简介
             @"groupID":@"groupID"// 唯一id
             };
}

@end

/**
 *  @author mimi, 15-04-27 11:04:07
 *
 *  在线组model
 */
@implementation OnlineGroupListModel

-(NSDictionary *)attributeMapDictionary
{
    return @{
             @"state":@"state",
             @"msg":@"msg",
             @"onlineGroups":@"onlineGroups"
             };
}

-(void)setOnlineGroups:(NSArray *)onlineGroups
{
    NSMutableArray* tmp = [NSMutableArray arrayWithCapacity:onlineGroups.count];
    for (id value in onlineGroups)
    {
        if ([value isKindOfClass:[NSDictionary class]])
        {
            OnlineGroupItem* item = [[OnlineGroupItem alloc] initWithDataDic:value];
            [tmp addObject:item];
        }
    }
    _onlineGroups = tmp;
}
@end
