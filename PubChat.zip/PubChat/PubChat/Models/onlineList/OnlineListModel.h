//
//  OnlineListModel.h
//  PubChat
//
//  Created by mimi on 15/4/27.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "BaseModel.h"
/**
 *  @author mimi, 15-04-27 11:04:14
 *
 *  在线用户item
 */
@interface OnlineUserItem : BaseModel
@property(nonatomic,strong) NSString* nickName;// 昵称
@property(nonatomic,strong) NSString* briefIntroduction;//简介
@property(nonatomic,strong) NSString* userID;// 唯一id
@end

/**
 *  @author mimi, 15-04-27 11:04:27
 *
 *  在线用户model
 */
@interface OnlineUserListModel : BaseModel
@property(nonatomic,strong) NSString* state;
@property(nonatomic,strong) NSDictionary*  onlineUsers;
@property(nonatomic,strong) NSString* msg;
@end

/**
 *  @author mimi, 15-04-27 11:04:47
 *
 *  在线组item
 */
@interface OnlineGroupItem : BaseModel
@property(nonatomic,strong) NSString* groupName;// 昵称
@property(nonatomic,strong) NSString* groupIntroduction;//简介
@property(nonatomic,strong) NSString* groupID;// 唯一id
@end

/**
 *  @author mimi, 15-04-27 11:04:07
 *
 *  在线组model
 */
@interface OnlineGroupListModel : BaseModel
@property(nonatomic,strong) NSString* state;
@property(nonatomic,strong) NSDictionary*  onlineGroups;
@property(nonatomic,strong) NSString* msg;
@end

