//
//  OnLineListApi.h
//  PubChat
//
//  Created by mimi on 15/4/27.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "OnlineListModel.h"

typedef void (^OnlineUserBlock)(OnlineUserListModel* model,NSString* errMsg);
typedef void (^OnlineGroupBlock)(OnlineGroupListModel* model,NSString* errMsg);

@interface OnLineListApi : NSObject

/**
 *  @author mimi, 15-04-27 11:04:59
 *
 *  获取在线用户列表
 *
 *  @param useruuid    登陆用户的uuid
 *  @param resultBlock 回调结果
 */
+(void) getOnlineUserList:(NSString*) userUID
              resultBlock:(OnlineUserBlock) resultBlock;

/**
 *  @author mimi, 15-04-27 15:04:08
 *
 *  获取在线组列表
 *
 *  @param userUID      登陆用户的uuid
 *  @param resultBlock  回调结果
 */
+(void) getOnlineGroupList:(NSString*) userUID
               resultBlock:(OnlineGroupBlock) resultBlock;

@end
