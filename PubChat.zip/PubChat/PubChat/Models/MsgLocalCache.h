//
//  MsgLocalCache.h
//  PubChat
//
//  Created by mimi on 15/4/30.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MsgLocalCache : NSObject

@property(readonly,strong,nonatomic) NSMutableDictionary* cacheDic;

+(MsgLocalCache*) defaultCache;

-(void) saveMsg:(NSArray*) msgs key:(NSString*) key;
-(NSMutableArray*) getMsgByKey:(NSString*) key;

-(void) cleanCache;
-(void) saveCache;
@end
