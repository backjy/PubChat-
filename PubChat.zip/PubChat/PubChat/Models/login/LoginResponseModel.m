//
//  LoginResponseModel.m
//  PubChat
//
//  Created by mimi on 15/4/24.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "LoginResponseModel.h"

@implementation LoginResponseModel

-(NSDictionary *)attributeMapDictionary
{
    return @{
             @"state":@"state",
             @"msg":@"msg",
             @"userID":@"userID"
             };
}

@end
