//
//  LoginApi.h
//  PubChat
//
//  Created by mimi on 15/4/24.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "LoginResponseModel.h"

typedef void (^LoginResponse)(LoginResponseModel* model,NSString* errMsg);

@interface LoginApi : NSObject

/**
 *  @author mimi, 15-04-24 09:04:28
 *
 *  发生登陆
 *
 *  @param nickName          昵称
 *  @param briefIntroduction 描述
 *  @param response          登陆回调
 */
+(void) postLogin:(NSString*) nickName
briefIntroduction:(NSString*) briefIntroduction
         Response:(LoginResponse) response;

@end
