//
//  LoginApi.m
//  PubChat
//
//  Created by mimi on 15/4/24.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "LoginApi.h"

#import "SocketClient.h"

@implementation LoginApi


/**
 *  @author mimi, 15-04-24 09:04:28
 *
 *  发生登陆
 *
 *  @param nickName          昵称
 *  @param briefIntroduction 描述、简介
 *  @param response          登陆回调
 */
+(void) postLogin:(NSString*) nickName
briefIntroduction:(NSString*) briefIntroduction
         Response:(LoginResponse) response
{
    NSDictionary* sendDic = @{
                               @"protocol":@"login",
                               @"userNickName":nickName,
                               @"briefIntroduction":briefIntroduction
                               };
    
    NSData* senData = [NSJSONSerialization dataWithJSONObject:sendDic options:NSJSONWritingPrettyPrinted error:nil];
    [[SocketClient currentClient] sendMessage:senData protocol:@"login" resultBlock:^(NSDictionary *data, NSString *errMsg)
     {
         if (data)
         {
             LoginResponseModel* repModel = [[LoginResponseModel alloc] initWithDataDic:data];
             response(repModel,repModel.msg);
         }
         else
         {
             response(nil, errMsg);
         }
    }];
}
@end
