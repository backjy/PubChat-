//
//  LoginResponseModel.h
//  PubChat
//
//  Created by mimi on 15/4/24.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "BaseModel.h"

/**
 *  @author mimi, 15-04-28 14:04:48
 *
 *  登陆回复model
 */
@interface LoginResponseModel : BaseModel

@property(strong,nonatomic) NSString* userID;// 登陆id

@property(strong,nonatomic) NSString* state;// 登陆状态

@property(strong,nonatomic) NSString* msg;// 

@end
