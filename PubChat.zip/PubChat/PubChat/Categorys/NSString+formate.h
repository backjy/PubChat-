//
//  NSString+formate.h
//  PubChat
//
//  Created by mimi on 15/4/23.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (formate)

/**
 *  是否是纯数字
 *
 *  @return
 */
-(BOOL) isPureNumber;
+(BOOL) isPureNumber:(NSString*) value;


@end
