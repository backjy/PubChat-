//
//  UIViewController+Storyboard.m
//  Socket
//
//  Created by mimi on 15/4/15.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "UIViewController+Storyboard.h"

@implementation UIViewController (Storyboard)

/**
 *  @author mimi, 15-04-15 14:04:20
 *
 *  获取 UIViewController from storyboardName with storyboardID
 *
 *  @param storyboardName storyboardName description
 *  @param storyboardID   storyboardID description
 *
 *  @return UIViewController
 */
+(UIViewController *)getCtrlFromStoryboardName:(NSString *)storyboardName
                              withStoryboardID:(NSString *)storyboardID
{
    UIStoryboard* storyboard = [UIStoryboard storyboardWithName:storyboardName bundle:nil];
    if (!storyboard)
    {
        NSLog(@"Local: not found %@ storyboard!",storyboardName);
        return nil;
    }
    UIViewController* viewController = [storyboard instantiateViewControllerWithIdentifier:storyboardID];
    if (!viewController)
    {
        NSLog(@"Local:view controller not found %@ in storyboard!",storyboardID);
        return nil;
    }
    return viewController;
}

@end
