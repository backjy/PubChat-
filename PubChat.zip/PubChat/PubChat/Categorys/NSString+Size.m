//
//  NSString+Size.m
//  RainbowFM
//
//  Created by Kratos on 14/12/14.
//  Copyright (c) 2014年 RB. All rights reserved.
//

#import "NSString+Size.h"

@implementation NSString (Size)

- (CGSize)calculateSize:(CGSize)size font:(UIFont *)font{
    CGSize expectedLabelSize = CGSizeZero;
    
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    NSDictionary *attributes = @{NSFontAttributeName:font, NSParagraphStyleAttributeName:paragraphStyle.copy};
    
    
    if ([self respondsToSelector:@selector(boundingRectWithSize:options:attributes:context:)]) {
        expectedLabelSize = [self boundingRectWithSize:size
                                               options:NSStringDrawingUsesLineFragmentOrigin
                                            attributes:attributes
                                               context:nil].size;
    } else {
        
        if ([self respondsToSelector:@selector(sizeWithAttributes:)])
            expectedLabelSize = [self sizeWithAttributes:attributes];
        else
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated"
            expectedLabelSize = [self sizeWithFont:font constrainedToSize:size];
#pragma clang diagnostic pop
        
    }
    
    return CGSizeMake(ceil(expectedLabelSize.width), ceil(expectedLabelSize.height));
}


@end
