//
//  NSString+Size.h
//  RainbowFM
//
//  Created by Kratos on 14/12/14.
//  Copyright (c) 2014年 RB. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSString (Size)
- (CGSize)calculateSize:(CGSize)size font:(UIFont *)font;
@end
