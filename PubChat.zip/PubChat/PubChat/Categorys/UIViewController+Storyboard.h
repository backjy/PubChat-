//
//  UIViewController+Storyboard.h
//  Socket
//
//  Created by mimi on 15/4/15.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Storyboard)

/**
 *  @author mimi, 15-04-15 14:04:20
 *
 *  获取 UIViewController from storyboardName with storyboardID
 *
 *  @param storyboardName storyboardName description
 *  @param storyboardID   storyboardID description
 *
 *  @return UIViewController
 */
+(UIViewController*) getCtrlFromStoryboardName:(NSString*) storyboardName
                              withStoryboardID:(NSString*) storyboardID;

@end
