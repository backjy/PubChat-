//
//  UIView+Xib.h
//  Socket
//
//  Created by mimi on 15/4/15.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Xib)

/**
 *  @author mimi, 15-04-15 14:04:50
 *
 *  获取xib 中的所有view
 *
 *  @param xibName xibName description
 *
 *  @return nsarray include views
 */
+(NSArray*) getViewsFromXibName:(NSString*) xibName;

/**
 *  @author mimi, 15-04-15 14:04:18
 *
 *  获取xib 最后一个view
 *
 *  @param xibName xibName description
 *
 *  @return 返回 getViewsFromXibName 返回数组中的lastone
 */
+(UIView*) getLastViewFromXibName:(NSString*) xibName;

/**
 *  @author mimi, 15-04-15 14:04:26
 *
 *  获取view xib 中所有为 viewClass 类型的 视图
 *
 *  @param xibName   xibName description
 *  @param viewClass viewClass description
 *
 *  @return return value description
 */
+(NSArray*) getViewsFromXibName:(NSString*)xibName
                 isKindOfClass:(Class) viewClass;

/**
 *  @author mimi, 15-04-15 14:04:26
 *
 *  获取view xib 中所有为 viewClass 类型 并且tag 相同的view
 *
 *  @param xibName   xibName description
 *  @param viewClass viewClass description
 *
 *  @return return value description
 */
+(NSArray*) getViewsFromXibName:(NSString*)xibName
                isKindOfClass:(Class) viewClass
                       withTag:(NSInteger) tag;
/**
 *  @author mimi, 15-04-15 14:04:26
 *
 *  获取view xib 中所有tag 相同的view
 *
 *  @param xibName   xibName description
 *  @param tag viewClass description
 *
 *  @return return value description
 */
+(NSArray*) getViewsFromXibName:(NSString*)xibName
                        withTag:(NSInteger) tag;

@end
