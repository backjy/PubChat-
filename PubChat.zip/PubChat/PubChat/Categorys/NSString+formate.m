//
//  NSString+formate.m
//  PubChat
//
//  Created by mimi on 15/4/23.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "NSString+formate.h"

@implementation NSString (formate)

/**
 *  是否是纯数字
 *
 *  @return
 */
-(BOOL)isPureNumber
{
    NSString * regex = @"\\d";
    NSPredicate * pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    return [pred evaluateWithObject:self];
}

+(BOOL)isPureNumber:(NSString *)value
{
    return [value isPureNumber];
}


@end
