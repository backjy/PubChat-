//
//  common_scoket.h
//  Socket
//
//  Created by mimi on 15/4/13.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#ifndef Socket_common_scoket_h
#define Socket_common_scoket_h

#define Service_host @"baidu.com"
#define Service_port 1101


#define MSG_HEAD_LENGTH 4

#define MSGMAP_PREFIX @"MSGMAP_PREFIX,"

#define SOCKET_CLIENT_RECIVEQUEUE_IDENTIFY "SOCKET_CLIENT_RECIVEQUEUE_IDENTIFY"

// 网络连接成功
#define SOCKET_CLIENT_MSG_DID_CONNECT       @"SOCKET_CLIENT_MSG_DID_CONNECT"
// 网络连接断开
#define SOCKET_CLIENT_MSG_DID_DISCONNECT    @"SOCKET_CLIENT_MSG_DID_DISCONNECT"
// 网络连接收到完整包
#define SOCKET_CLIENT_MSG_DID_RECIVEMSG    @"SOCKET_CLIENT_MSG_DID_RECIVEMSG"

typedef void (^SocketClientBlock)(NSDictionary* data,NSString* errMsg);

typedef void (^SocketClientConnectBlock)(BOOL state,NSError* error);

#endif
