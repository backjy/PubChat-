//
//  MessageDistribution.h
//  Socket
//
//  Created by mimi on 15/4/14.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import <Foundation/Foundation.h>


#import "common_scoket.h"

@interface Message_info : NSObject
@property(nonatomic, assign) BOOL isReciving;
@property(nonatomic, assign) NSInteger tag;
@property(nonatomic, assign) NSInteger length;
@property(nonatomic, weak)   id target;
@property(nonatomic, strong) NSString* protocol;
@property(nonatomic, strong) SocketClientBlock resultBlock;
@end


@interface SocketMessageDistribution : NSObject

@property(nonatomic,assign) NSUInteger msgHeaderSize;


/**
 *  @author mimi, 15-04-14 10:04:29
 *
 *  接受注册包回调地方
 *
 *  @param protocol    消息协议号
 *  @param reciveBlock reciveBlock description
 */
-(void) registerRecive:(NSString*) protocol
                target:(id) target
          recivedBlock:(SocketClientBlock) reciveBlock;

/**
 *  @author mimi, 15-04-29 11:04:49
 *
 *  注销消息收取回调
 *
 *  @param protocol 消息协议号
 *  @param target   收取者
 */
-(void) unRegisterRecived:(NSString*) protocol
                   target:(id) target;


/**
 *  @author mimi, 15-04-20 16:04:49
 *
 *  获取添加长度后的内容
 *
 *  @param data 源数据
 *
 *  @return 添加head 后的数据
 */
-(NSData*) getDataWithHeader:(NSData*) data;

/**
 *  @author mimi, 15-04-14 09:04:02
 *
 *  获取长度
 *
 *  @param info info description
 *
 *  @return return value description
 */
-(NSInteger) packageLength:(NSData*) info;


/**
 *  @author mimi, 15-04-14 12:04:53
 *
 *  收到包并且分发出去
 *
 *  @param data        收到的数据
 *  @param waitRecives 正在等待收包的队列
 */
-(void) reciveData:(NSData *)data
      waitRecives:(NSMutableDictionary *)waitRecives;

@end
