//
//  SocketClient.m
//  Socket
//
//  Created by mimi on 15/4/12.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "SocketClient.h"

#import <CocoaAsyncSocket/GCDAsyncSocket.h>

#import "SocketMsgDistribution.h"

@interface SocketClient()<GCDAsyncSocketDelegate,NSStreamDelegate>
{
}
@property(nonatomic, assign) NSInteger messageTag;
@property(nonatomic, strong) NSMutableDictionary* reciveMessageQueue;
@property(nonatomic, strong) NSMutableDictionary* sendMessageQueue;
@property(nonatomic, strong) NSMutableArray* autoReciveQueue;
@property(nonatomic, strong) NSTimer* autoReciveTimer;
@end

@implementation SocketClient

+(SocketClient *)currentClient
{
    static SocketClient* _currentClient = nil;
    @synchronized(self)
    {
        if (!_currentClient)
        {
            _currentClient = [SocketClient new];
        }
    }
    return _currentClient;
}

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        _socket             = [[GCDAsyncSocket alloc] initWithDelegate:self
                                               delegateQueue:dispatch_get_main_queue()];
        _messageTag         = 0;
        _autoReciveTimer    = nil;
        _reciveMessageQueue = [NSMutableDictionary new];
        _sendMessageQueue   = [NSMutableDictionary new];
        _autoReciveQueue    = [NSMutableArray new];
        
        _msgDistribution    = [SocketMessageDistribution new];
    }
    return self;
}

-(BOOL)isConnected
{
    return _socket.isConnected;
}

/**
 *  @author mimi, 15-04-14 10:04:29
 *
 *  连接服务器
 */
-(void)connectToHost:(SocketClientConnectBlock)connectBlock
{
    _connectBlock = connectBlock;
    if (_socket)
    {
        if(_socket.isConnected)
        {
            [_socket disconnect];
        }
        [_socket connectToHost:_host onPort:_port error:nil];
    }
}

/**
 *  @author mimi, 15-04-14 10:04:17
 *
 *  断开连接
 */
-(void)disConnect
{
    if (_socket.isConnected)
    {
        [_socket disconnect];
    }
    [_reciveMessageQueue removeAllObjects];
    [_sendMessageQueue removeAllObjects];
    [_autoReciveQueue removeAllObjects];
}

/**
 *  @author mimi, 15-04-14 10:04:43
 *
 *  获取message 的tag 
 *  tag 每次获取时自动递增
 *
 *  @return tag
 */
-(NSInteger)messageTag
{
    _messageTag = _messageTag<NSIntegerMax?++_messageTag:0;
    return _messageTag;
}

-(NSUInteger) sendMessage:(NSData*) package
                 protocol:(NSString*) protocol
              resultBlock:(SocketClientBlock) resultBlock
{
    NSUInteger tag     = self.messageTag;
    NSData* sendData = [self.msgDistribution getDataWithHeader:package];
    [_socket writeData:sendData withTimeout:30 tag:tag];

    if (resultBlock)
    {
        Message_info* info = [Message_info new];
        info.tag           = tag;
        info.protocol      = protocol;
        info.resultBlock   = resultBlock;
        [_sendMessageQueue setObject:info forKey:[NSNumber numberWithInteger:tag].stringValue];
    }
    return 0;
}

-(NSTimer *)autoReciveTimer
{
    if (!_autoReciveTimer)
    {
        _autoReciveTimer = [NSTimer scheduledTimerWithTimeInterval:0.1
                                                            target:self
                                                          selector:@selector(autoRecivePackage)
                                                          userInfo:nil
                                                           repeats:YES];
    }
    //暂停计时器
    [_autoReciveTimer setFireDate:[NSDate distantFuture]];
    return _autoReciveTimer;
}

/**
 *  @author mimi, 15-04-14 08:04:35
 *
 *  创建一个自动收包信息
 *
 *  @param tag tag description
 *
 *  @return return 返回一个messageinfo
 */
-(Message_info*) createMessageInfo:(NSUInteger) tag
{
    Message_info* info = [Message_info new];
    info.tag           = tag;
    return info;
}

/**
 *  @author mimi, 15-04-14 09:04:52
 *
 *  定时器自动收包
 */
-(void) autoRecivePackage
{
    if (!_socket || !_socket.isConnected)
    {
        // 如果连接断开了 就直接 并且return
        [self.autoReciveTimer setFireDate:[NSDate distantFuture]];
        return;
    }
    
    if (_autoReciveQueue.count == 0)
    {
        // 自动收包里面没有内容了就创建一条
        NSUInteger tag = self.messageTag;
        [_autoReciveQueue addObject:[self createMessageInfo:tag]];
    }
//    开始处理收包逻辑 进行包得分拆 
    if (_autoReciveQueue.count <= 0)
    {
        return;
    }
    Message_info* info = [_autoReciveQueue firstObject];
    if (!info.isReciving)
    {
        if(info.length == 0)
        {
            //读取该包的head
            [_socket readDataToLength:self.msgDistribution.msgHeaderSize withTimeout:-1 tag:info.tag];
            info.isReciving = YES;
        }
        else
        {
            //读取该包的内容
            [_socket readDataToLength:info.length withTimeout:-1 tag:info.tag];
            info.isReciving = YES;
        }
    }
}


/**
 *  @author mimi, 15-04-13 16:04:47
 *
 *  socket 连接到
 *
 *  @param sock sock description
 *  @param host host description
 *  @param port port description
 */
-(void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port
{
    [[NSNotificationCenter defaultCenter] postNotificationName:SOCKET_CLIENT_MSG_DID_CONNECT
                                                        object:self
                                                      userInfo:nil];
    // 让socket 在后台执行
    [sock performBlock:^{
        [sock enableBackgroundingOnSocket];
    }];
    // 开始计时器
    [self.autoReciveTimer  setFireDate:[NSDate distantPast]];
    if (_connectBlock)
    {
        _connectBlock(YES, nil);
    }
}

/**
 *  @author mimi, 15-04-13 16:04:27
 *
 *  socket 连接断开
 *
 *  @param sock sock description
 *  @param err  err description
 */
-(void)socketDidDisconnect:(GCDAsyncSocket *)sock withError:(NSError *)err
{
    [[NSNotificationCenter defaultCenter] postNotificationName:SOCKET_CLIENT_MSG_DID_DISCONNECT
                                                        object:self
                                                      userInfo:err.userInfo];
    [self disConnect];
    
    if (_connectBlock)
    {
        _connectBlock(YES, err);
    }
}

/**
 *  @author mimi, 15-04-14 08:04:32
 *
 *  写入一个数据成功
 *  将该数据放入到等待收包的字典里面 key 为protocol
 *
 *  @param sock sock description
 *  @param tag  tag description
 */
-(void)socket:(GCDAsyncSocket *)sock didWriteDataWithTag:(long)tag
{
    NSString* tagKey = [NSNumber numberWithInteger:tag].stringValue;
    Message_info* sendInfo = [_sendMessageQueue objectForKey:tagKey];
    if (sendInfo)
    {
        Message_info* reciveInfo = [_reciveMessageQueue objectForKey:sendInfo.protocol];
        if (reciveInfo)
        {
            NSError* error = [NSError errorWithDomain:@"recive info cover!" code:-1 userInfo:nil];
            reciveInfo.resultBlock(nil,[NSString stringWithFormat:@"%@",error.domain]);
        }
        //添加该包到等待收取队列中
        [_reciveMessageQueue setObject:sendInfo forKey:sendInfo.protocol];
    }
}

/**
 *  @author mimi, 15-04-13 21:04:30
 *
 *  收到数据
 *
 *  @param sock sock description
 *  @param data data description
 *  @param tag  tag description
 */
-(void) socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag
{
    Message_info* waitReciveInfo = _autoReciveQueue.firstObject;
    if (!waitReciveInfo)
    {
        // 如果出现在这里说明收发包顺序已经混乱 需要断开连接 重新来
        [self disConnect];
        return;
    }
    
    if (waitReciveInfo.length == 0)
    {
        BOOL hasError = NO;
        if (data.length != self.msgDistribution.msgHeaderSize)
        {
            //读取长度出错
            hasError = YES;
        }
        else
        {
            NSInteger length = [self.msgDistribution packageLength:data];
            if (length <= 0)
            {
                hasError = YES;
            }
            else
            {
                waitReciveInfo.length = length;
                waitReciveInfo.isReciving = NO;
            }
        }
        if (hasError) {
            [self disConnect];
            return;
        }
    }
    else
    {
        if (waitReciveInfo.length > 0 &&
            data.length == waitReciveInfo.length)
        {
            //处理收到的包
            waitReciveInfo.isReciving = NO;
            [_autoReciveQueue removeObject:waitReciveInfo];
            [self handleReciveMessage:data];
        }
    }
    
}

/**
 *  @author mimi, 15-04-14 09:04:49
 *
 *  处理完整的包
 *
 *  @param data
 */
-(void) handleReciveMessage:(NSData*) data
{
    [self.msgDistribution reciveData:data waitRecives:_reciveMessageQueue];
}


@end
