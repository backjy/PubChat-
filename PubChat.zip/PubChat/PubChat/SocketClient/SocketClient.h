//
//  SocketClient.h
//  Socket
//
//  Created by mimi on 15/4/12.
//  Copyright (c) 2015年 mimi. All rights reserved.
//
//  负责处理网络数据
#import <Foundation/Foundation.h>

#import "common_scoket.h"

@class SocketMessageDistribution;
@class GCDAsyncSocket;


@interface SocketClient : NSObject

@property(nonatomic,strong) NSString* host; // host name
@property(nonatomic,assign) uint16_t  port; // port
@property(nonatomic,readonly, strong) GCDAsyncSocket* socket; // gcd socket

@property(nonatomic,readonly) BOOL isConnected;

@property(nonatomic,strong) SocketMessageDistribution* msgDistribution;
@property(nonatomic,strong) SocketClientConnectBlock connectBlock;

+(SocketClient*) currentClient;

/**
 *  @author mimi, 15-04-14 10:04:29
 *
 *  连接服务器
 */
-(void) connectToHost:(SocketClientConnectBlock) connectBlock;

/**
 *  @author mimi, 15-04-14 10:04:17
 *
 *  断开连接
 */
-(void) disConnect;


/**
 *  @author mimi, 15-04-14 10:04:48
 *
 *  发送一个包
 *
 *  @param package     package description
 *  @param protocol    protocol description
 *  @param resultBlock resultBlock description
 *
 *  @return 返回发送包的tag
 */
-(NSUInteger) sendMessage:(NSData*) package
                 protocol:(NSString*) protocol
              resultBlock:(SocketClientBlock) resultBlock;


@end
