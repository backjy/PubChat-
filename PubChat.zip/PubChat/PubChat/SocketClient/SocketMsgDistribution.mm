//
//  SocketMessageDistribution.m
//  Socket
//
//  Created by mimi on 15/4/14.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "SocketMsgDistribution.h"

#import "GTMBase64.h"

@implementation Message_info
- (instancetype)init
{
    self = [super init];
    if (self) {
        _protocol = @"";
        _resultBlock = nil;
        _length = 0;
        _isReciving = NO;
        _target = nil;
    }
    return self;
}
@end


@interface SocketMessageDistribution()

@property(nonatomic, strong) NSMutableDictionary* registerMap;


@end

@implementation SocketMessageDistribution

- (instancetype)init
{
    self = [super init];
    if (self)
    {
        _msgHeaderSize = MSG_HEAD_LENGTH;
        _registerMap = [NSMutableDictionary new];
    }
    return self;
}

/**
 *  @author mimi, 15-04-20 16:04:06
 *
 *  把 uint32 4个字节拷贝到 buffer
 *
 *  @param value  要拷贝的值
 *  @param buffer 拷贝到那里
 *  @param length 拷贝的长度
 */
static void CopyUInt32ToBytes(void* value,unsigned char* buffer,uint16_t length)
{
    memset(buffer, 0, length);
    memcpy(buffer, value, length);
}

/**
 *  @author mimi, 15-04-20 16:04:49
 *
 *  获取添加长度后的内容
 *
 *  @param data 源数据
 *
 *  @return 添加head 后的数据
 */
-(NSData*) getDataWithHeader:(NSData*) data
{
    // 使用默认的little 字节序 不适用big 字节序
    NSData* encodeData = [GTMBase64 encodeData:data];
    unsigned char headBuffer[4];
    uint32_t headerLength = (uint32_t)encodeData.length;
    CopyUInt32ToBytes(&headerLength, headBuffer, 4);
    NSMutableData* pRet = [[NSMutableData alloc] initWithBytes:headBuffer length:4];
    [pRet appendData:encodeData];
    return pRet;
}



/**
 *  @author mimi, 15-04-14 09:04:02
 *
 *  获取长度
 *
 *  @param info info description
 *
 *  @return return value description
 */
-(NSInteger) packageLength:(NSData*) info
{
    if (info && info.length == MSG_HEAD_LENGTH)
    {
        int32_t retValue = 0;
        memcpy(&retValue, info.bytes, sizeof(unsigned char) * 4);
        return retValue;
    }
    return -1;
}


/**
 *  @author mimi, 15-04-14 10:04:29
 *
 *  接受注册包回调地方
 *
 *  @param protocol    protocol description
 *  @param reciveBlock reciveBlock description
 */
-(void) registerRecive:(NSString*) protocol
          recivedBlock:(SocketClientBlock) reciveBlock
{
    if (!reciveBlock)
    {
        return;
    }
    Message_info* info = [Message_info new];
    info.protocol = protocol;
    info.resultBlock = reciveBlock;
    [_registerMap setValue:info forKey:protocol];
}

/**
 *  @author mimi, 15-04-14 10:04:29
 *
 *  接受注册包回调地方
 *
 *  @param protocol    消息协议号
 *  @param reciveBlock reciveBlock description
 */
-(void) registerRecive:(NSString*) protocol
                target:(id) target
          recivedBlock:(SocketClientBlock) reciveBlock
{
    if(!reciveBlock || !target || !protocol)
    {
        return;
    }
    NSMutableArray* registers = [_registerMap objectForKey:protocol];
    if (!registers)
    {
        registers = [NSMutableArray arrayWithCapacity:1];
        [_registerMap setValue:registers forKey:protocol];
    }
    [self unRegisterRecived:protocol target:target];
    Message_info* info = [Message_info new];
//    info.protocol      = protocol;
    info.resultBlock   = reciveBlock;
    info.target        = target;
    [registers addObject:info];
}

/**
 *  @author mimi, 15-04-29 11:04:49
 *
 *  注销消息收取回调
 *
 *  @param protocol 消息协议号
 *  @param target   收取者
 */
-(void) unRegisterRecived:(NSString*) protocol
                   target:(id) target
{
    if (!protocol || !target)
    {
        return;
    }
    
    NSMutableArray* registers = [_registerMap objectForKey:protocol];
    for (Message_info* info in registers)
    {
        if (info.target == target)
        {
            [registers removeObject:info];
            break;
        }
    }
}


/**
 *  @author mimi, 15-04-14 12:04:53
 *
 *  收到包并且分发出去
 *
 *  @param data        收到的数据
 *  @param waitRecives 正在等待收包的队列
 */
-(void)reciveData:(NSData *)data waitRecives:(NSMutableDictionary *)waitRecives
{
    NSData* decodeData = [GTMBase64 decodeData:data];
    NSDictionary* jsonData = [NSJSONSerialization JSONObjectWithData:decodeData options:kNilOptions error:nil];
    NSString* protocol = [jsonData objectForKey:@"protocol"];
    if (protocol)
    {
        Message_info* reciveInfo = [waitRecives objectForKey:protocol];
        if (reciveInfo)
        {
            reciveInfo.resultBlock( jsonData,nil);
            [waitRecives removeObjectForKey:protocol];
            return;
        }
        NSMutableArray* recivers = [self.registerMap objectForKey:protocol];
        if (recivers && recivers.count > 0)
        {
            NSMutableArray* removeRecivers = [NSMutableArray arrayWithCapacity:recivers.count];
            for (Message_info* info in recivers)
            {
                if (info.target)
                {
                    info.resultBlock(jsonData,nil);
                }
                else
                {
                    [removeRecivers addObject:info];
                }
            }
            [recivers removeObjectsInArray:removeRecivers];
        }
        else
        {
            [[NSNotificationCenter defaultCenter] postNotificationName:SOCKET_CLIENT_MSG_DID_RECIVEMSG
                                                                object:self
                                                              userInfo:jsonData];
        }
    }
}

@end
