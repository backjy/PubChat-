//
//  common_protocol.h
//  Socket
//
//  Created by mimi on 15/4/13.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#ifndef Socket_common_protocol_h
#define Socket_common_protocol_h

typedef NS_ENUM(NSUInteger, Socket_Protocols)
{
    MSG_A = 0X0001,
    MSG_B,
    MSG_C,
};

#endif
