//
//  ChatListController.m
//  PubChat
//
//  Created by mimi on 15/4/27.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "ChatListController.h"

#import "SocketClient.h"

#import "OnLineListApi.h"

#import "UserInfo.h"

#import "ChatListUserCell.h"

#import "ChatViewController.h"
#import "UIViewController+Storyboard.h"

#import <MJRefresh.h>


@interface ChatListController ()<UITableViewDataSource, UITableViewDelegate>
{
    NSInteger currentSelected;
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentControl;

@property(nonatomic, strong) NSArray* dataSource;
@property(nonatomic, strong) NSDictionary* sourceData;

@end

static NSString* const sChatListUserCellIdentify = @"sChatListUserCellIdentify";

@implementation ChatListController


-(void)viewDidLoad
{
    currentSelected = 0;
    [_segmentControl addTarget:self action:@selector(segmentValueChanged:) forControlEvents:UIControlEventValueChanged];
    [_segmentControl setSelectedSegmentIndex:0];
    [self onlineUsersAction];
    
    //
    _tableView.delegate = self;
    _tableView.dataSource = self;
    
    [_tableView registerNib:[UINib nibWithNibName:@"ChatListUserCell" bundle:nil] forCellReuseIdentifier:sChatListUserCellIdentify];
    
    __weak typeof(self) blockSelf = self;
    // 添加传统的下拉刷新
    [self.tableView addLegendHeaderWithRefreshingBlock:^{
        // 进入刷新状态后会自动调用这个block
        if (blockSelf)
        {
            [blockSelf onlineUsersAction];
//            blockSelf.tableView 
        }
    }];
}

/**
 *  @author mimi, 15-04-27 10:04:36
 *
 *  刷新内容
 *
 *  @param sender
 */
- (IBAction)refreshAction:(id)sender
{
    
}

/**
 *  @author mimi, 15-04-27 10:04:26
 *
 *  segment value changed
 *
 *  @param control
 */
-(void) segmentValueChanged:(UISegmentedControl*) control
{
    currentSelected = control.selectedSegmentIndex;
    if(control.selectedSegmentIndex == 0)
    {
        [self onlineUsersAction];
    }
    else
    {
        [self onlineGroupsAction];
    }
}

/**
 *  @author mimi, 15-04-27 10:04:59
 *
 *  在线列表action
 *
 *  @param sender
 */
-(void) onlineUsersAction
{
    __weak typeof(self) blockSelf = self;
    [OnLineListApi getOnlineUserList:[UserInfo currentUser].userID
                         resultBlock:^(OnlineUserListModel *model, NSString *errMsg)
     {
         NSLog(@"successed");
         if (blockSelf)
         {
             blockSelf.sourceData = model.onlineUsers;
             blockSelf.dataSource = _sourceData.allKeys;
             [blockSelf.tableView reloadData];
             if (blockSelf.tableView.header.isRefreshing)
             {
                 [blockSelf.tableView.header endRefreshing];
             };
         }
     }];
}

/**
 *  @author mimi, 15-04-27 10:04:18
 *
 *  聊天组 action
 *
 *  @param sender
 */
-(void) onlineGroupsAction
{
    
}

#pragma mark - tableview delegates
#pragma mark tableview delegates

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataSource? _dataSource.count: 0;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:sChatListUserCellIdentify];
    if ([cell isKindOfClass:[ChatListUserCell class]])
    {
        ChatListUserCell* infoCell = (ChatListUserCell*) cell;
        NSString* dataKey = [_dataSource objectAtIndex:indexPath.row];
        NSString* nickName = @"nick";
        NSString* introduction =  @"introduction";
        if (currentSelected == 0)
        {
            nickName = ((OnlineUserItem*)[_sourceData objectForKey:dataKey]).nickName;
            introduction = ((OnlineUserItem*)[_sourceData objectForKey:dataKey]).briefIntroduction;
        }
        else
        {
            
        }
        infoCell.nickName.text = nickName;
        infoCell.introduction.text = introduction;
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString* dataKey = [_dataSource objectAtIndex:indexPath.row];
    ChatViewController* controller = (ChatViewController*)[UIViewController getCtrlFromStoryboardName:@"ChatView" withStoryboardID:@"ChatViewController"];
    controller.chatUser = [_sourceData objectForKey:dataKey];
    [self.navigationController pushViewController:controller animated:YES];
}


@end
