//
//  ChatTabViewController.m
//  PubChat
//
//  Created by mimi on 15/4/29.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "ChatTabViewController.h"

#import "SocketClient.h"

@interface ChatTabViewController ()

@end

@implementation ChatTabViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated
{
    self.navigationItem.title = @"聊天列表";
//    [self setSelectedIndex:1];
}


/**
 *  @author mimi, 15-04-27 10:04:20
 *
 *  后退到服务器界面
 *
 *  @param sender
 */
- (IBAction)backAction:(id)sender
{
    [[SocketClient currentClient] disConnect];
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - delegates

-(void)tabBar:(UITabBar *)tabBar didSelectItem:(UITabBarItem *)item
{
    NSString* title = item.title;
    self.navigationItem.title = title;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
