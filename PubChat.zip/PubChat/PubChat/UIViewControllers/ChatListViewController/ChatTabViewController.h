//
//  ChatTabViewController.h
//  PubChat
//
//  Created by mimi on 15/4/29.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatTabViewController : UITabBarController

@end
