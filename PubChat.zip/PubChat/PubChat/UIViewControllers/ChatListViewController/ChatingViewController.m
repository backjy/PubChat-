//
//  ChatingViewController.m
//  PubChat
//
//  Created by mimi on 15/4/29.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "ChatingViewController.h"

#import "SocketClient.h"

#import "SocketMsgDistribution.h"
#import "ChatModel.h"
#import "ChatViewController.h"
#import "UIViewController+Storyboard.h"
#import "MsgLocalCache.h"

@interface ChatingViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) NSMutableArray* dataSource;
@end

@implementation ChatingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self registerServiceMsg];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _dataSource = [NSMutableArray arrayWithCapacity:10];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(observerNewChatEvent:)
                                                 name:sNewChatEvent
                                               object:nil];
}

- (void)dealloc
{
    //注销 服务器主动消息通知 @"msgSTC"
    SocketMessageDistribution* msgDistribution = [SocketClient currentClient].msgDistribution;
    [msgDistribution unRegisterRecived:@"msgSTC" target:self];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

/**
 *  @author mimi, 15-04-30 12:04:28
 *
 *  收到新的聊天信息
 *
 *  @param noti
 */
-(void) observerNewChatEvent:(NSNotification*) noti
{
    BOOL isNewEvent = YES;
    ChatEventModel* event = noti.object;
    if (event)
    {
        for (ChatEventModel* oldEvent in _dataSource)
        {
            if ([oldEvent.msgSender isEqualToString:event.msgSender])
            {
                isNewEvent = NO;
                break;
            }
        }
    }
    if (isNewEvent)
    {
        [_dataSource insertObject:event atIndex:0];
        [_tableView reloadData];
    }
}

/**
 *  @author mimi, 15-04-29 11:04:47
 *
 *  注册 服务器主动消息通知 @"msgSTC"
 */
-(void) registerServiceMsg
{
    __weak typeof(self) blockSelf = self;
    SocketMessageDistribution* msgDistribution = [SocketClient currentClient].msgDistribution;
    [msgDistribution registerRecive:@"msgSTC"
                             target:self
                       recivedBlock:^(NSDictionary *data, NSString *errMsg)
     {
         if (blockSelf && data)
         {
             ChatAutoReciveModel* model = [[ChatAutoReciveModel alloc] initWithDataDic:data];
             ChatEventModel* event = [ChatEventModel new];
             event.chatType = model.chatType;
             event.msgSender = model.msgFrom;
             event.msgSenderNick = model.msgFNick;
             [[NSNotificationCenter defaultCenter] postNotificationName:sNewChatEvent
                                                                 object:event
                                                               userInfo:nil];
             
             /**
              *  @author mimi, 15-04-30 14:04:33
              *
              *  写入local msg chache
              */
             NSMutableArray* localCache = [[MsgLocalCache defaultCache] getMsgByKey:model.msgFrom];
             ChatMessageModel* msgCellModel = [ChatMessageModel createMessageWith:model];
             if (localCache && msgCellModel)
             {
                 [localCache addObject:msgCellModel];
             }
             /**
              *  @author mimi, 15-04-30 14:04:47
              *
              *  发送新消息通知
              */
             [[NSNotificationCenter defaultCenter] postNotificationName:sNewMessageEvent
                                                                 object:msgCellModel
                                                               userInfo:nil];
         }
     }];

}

#pragma mark - tableview delegates
#pragma mark tableview delegates

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dataSource? _dataSource.count: 0;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        ChatEventModel* event = [_dataSource objectAtIndex:indexPath.row];
        cell.textLabel.text = event.msgSenderNick;
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ChatEventModel* event = [_dataSource objectAtIndex:indexPath.row];
    OnlineUserItem* user = [OnlineUserItem new];
    user.nickName = event.msgSenderNick;
    user.userID = event.msgSender;
    ChatViewController* controller = (ChatViewController*)[UIViewController getCtrlFromStoryboardName:@"ChatView" withStoryboardID:@"ChatViewController"];
    controller.chatUser = user;
    [self.navigationController pushViewController:controller animated:YES];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
