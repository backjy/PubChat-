//
//  ChatViewController.m
//  Socket
//
//  Created by mimi on 15/4/15.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "ChatViewController.h"

#import "ChatViewInputBarView.h"

#import <IQKeyboardManager.h>
#import <IQKeyboardReturnKeyHandler.h>

#import "ChatApi.h"
#import "UserInfo.h"
#import "SocketClient.h"
#import "SocketMsgDistribution.h"

#import "ChatReciveMsgTableViewCell.h"
#import "ChatSendMsgTableViewCell.h"

#import "MsgLocalCache.h"

@interface ChatViewController ()<UITextFieldDelegate,UITextViewDelegate,
                                UITableViewDataSource,UITableViewDelegate>
{
    IQKeyboardReturnKeyHandler* keyboardHandler;
    UITapGestureRecognizer* tapGesture;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet ChatViewInputBarView *inputBar;
@property (strong, nonatomic) NSMutableArray* messageData;
@end

@implementation ChatViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    keyboardHandler = [[IQKeyboardReturnKeyHandler alloc] initWithViewController:self];
    keyboardHandler.delegate = self;
    // Do any additional setup after loading the view.
    tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapGesture:)];
    [self.view addGestureRecognizer:tapGesture];
    
    [_inputBar.sendButton addTarget:self action:@selector(sendMessageAction:) forControlEvents:UIControlEventTouchUpInside];
    
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [_tableView registerNib:[UINib nibWithNibName:@"ChatSendMsgTableViewCell" bundle:nil] forCellReuseIdentifier:sChatingMsgSelfCellIdentify];
    [_tableView registerNib:[UINib nibWithNibName:@"ChatReciveMsgTableViewCell" bundle:nil] forCellReuseIdentifier:sChatingMsgTargetCellIdentify];
    
    _messageData = [[MsgLocalCache defaultCache] getMsgByKey:_chatUser.userID];
    
    [_tableView reloadData];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(recivedMessage:)
                                                 name:sNewMessageEvent
                                               object:nil];
}

- (void)dealloc
{
    keyboardHandler = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)viewWillAppear:(BOOL)animated
{
    self.navigationItem.title = _chatUser.nickName;
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:NO];
}
//-(void)

-(void) viewWillDisappear:(BOOL)animated
{
    [[IQKeyboardManager sharedManager] setEnable:NO];
    //    注销 服务器主动消息通知 @"msgSTC"
}

/**
 *  @author mimi, 15-04-15 15:04:07
 *
 *  收到return 回调函数
 *
 *  @param textField
 */
-(void) textFieldDidEndEditing:(UITextField *)textField
{
    [keyboardHandler removeResponderFromView:textField];
}

-(void) tapGesture:(UITapGestureRecognizer*) sender
{
    if ([_inputBar.inputField isFirstResponder])
    {
        CGPoint location = [sender locationInView:self.view];
        if (!CGRectContainsPoint(_inputBar.frame, location))
        {
            [_inputBar.inputField endEditing:YES];
        }
    }
}

/**
 *  @author mimi, 15-04-29 14:04:24
 *
 *  发送消息
 *
 *  @param sender
 */
-(void) sendMessageAction:(UIButton*) sender
{
    NSString* sendMessage = _inputBar.inputField.text;
    _inputBar.inputField.text = @"";
    if (![sendMessage isEqualToString:@""])
    {
        __weak typeof(self) blockSelf = self;
        ChatMessageModel* msgCellModel = [ChatMessageModel createMessageWithSend:sendMessage
                                                                         msgType:@"work"
                                                                        chatType:@"userToUser"                                                                       msgSender:[UserInfo currentUser].userID
                                                                           msgID:-1
                                                                          isSelf:YES];
        [self.messageData addObject:msgCellModel];
        [_tableView scrollToNearestSelectedRowAtScrollPosition:UITableViewScrollPositionBottom animated:YES];
        [_tableView reloadData];
        /**
         *  @author mimi, 15-04-30 13:04:36
         *
         *  发送事件
         */
        ChatEventModel* event = [ChatEventModel new];
        event.chatType = @"userToUser";
        event.msgSender = _chatUser.userID;
        event.msgSenderNick = _chatUser.nickName;
        [[NSNotificationCenter defaultCenter] postNotificationName:sNewChatEvent
                                                            object:event
                                                          userInfo:nil];
        /**
         *  @author mimi, 15-04-30 13:04:52
         *
         *  发送消息
         */
        msgCellModel.msgID = [ChatApi sendMessageFrom:[UserInfo currentUser].userID
                                                   to:_chatUser.userID
                                          messageType:@"word"
                                             chatType:@"userToUser"
                                       messageContent:sendMessage
                                             response:^(ChatPostResponseModel *model, NSString *msg)
                              {
                                  for (NSInteger i = _messageData.count - 1; i >= 0; i--)
                                  {
                                      ChatMessageModel* msgCellModel = [_messageData objectAtIndex:i];
                                      if (msgCellModel.msgID == model.msgID.integerValue)
                                      {
                                          msgCellModel.msgState = 1;
                                          if (model.state.integerValue != 1)
                                          {
                                              msgCellModel.msgContent = [NSString stringWithFormat:@"%@\n%@",
                                                                  msgCellModel.msgContent,msg];
                                          }
                                          break;
                                      }
                                  }
                                  if (blockSelf)
                                  {
                                      [blockSelf.tableView reloadData];
                                  }
                              }];
    }
}

/**
 *  @author mimi, 15-04-29 14:04:17
 *
 *  正在聊天界面收到 对面发送来得消息
 *
 *  @param model 消息
 */
-(void) recivedMessage:(NSNotification*) notify
{
    if ([notify.object isKindOfClass:[ChatMessageModel class]])
    {
        ChatMessageModel* msgCellModel = notify.object;
        if ([msgCellModel.msgSender isEqualToString:_chatUser.userID])
        {
            [_tableView reloadData];
        }
    }
}


#pragma mark - tableview delegates
#pragma mark tableview delegates

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _messageData.count?_messageData.count:0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat height = 0;
    ChatMessageModel* sendMsgModel = [_messageData objectAtIndex:indexPath.row];
    if (sendMsgModel.isSelf)
    {
        height = 44 + [sendMsgModel getMessageContentHeight:CGRectGetWidth(_tableView.frame) - 119.0f
                                                  orgHeight:22
                                                     UIFont:[UIFont systemFontOfSize:14]];
    }
    else
    {
        height = 53 + [sendMsgModel getMessageContentHeight:CGRectGetWidth(_tableView.frame)
                                                  orgHeight:22
                                                     UIFont:[UIFont systemFontOfSize:14]];
    }
    return height;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    id cell = nil;
    ChatMessageModel* sendMsgModel = [_messageData objectAtIndex:indexPath.row];
    if (sendMsgModel.isSelf)
    {
        cell = (ChatSendMsgTableViewCell*)[tableView dequeueReusableCellWithIdentifier:sChatingMsgSelfCellIdentify];
        [self setCellWithSelf:cell model:sendMsgModel];
    }
    else
    {
        cell = (ChatReciveMsgTableViewCell*)[tableView dequeueReusableCellWithIdentifier:sChatingMsgTargetCellIdentify];
        [self setCellWithRecive:cell model:sendMsgModel];
    }
    return cell;
}

-(void) setCellWithSelf:(ChatSendMsgTableViewCell*) cell model:(ChatMessageModel*) model
{
    if (model.msgState)
    {
        [cell.activityIndicator stopAnimating];
        [cell.activityIndicator setHidden:YES];
    }
    else
    {
        [cell.activityIndicator startAnimating];
    }
    cell.msgContent.text = model.msgContent;
}

-(void) setCellWithRecive:(ChatReciveMsgTableViewCell*) cell model:(ChatMessageModel*) model
{
    cell.sender.text = model.msgSenderNick;
    cell.content.text = model.msgContent;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
