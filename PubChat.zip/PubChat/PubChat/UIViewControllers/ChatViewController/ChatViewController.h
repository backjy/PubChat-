//
//  ChatViewController.h
//  Socket
//
//  Created by mimi on 15/4/15.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "OnlineListModel.h"

@interface ChatViewController : UIViewController

@property(nonatomic,strong) OnlineUserItem* chatUser;

@end
