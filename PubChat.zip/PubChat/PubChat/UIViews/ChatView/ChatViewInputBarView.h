//
//  ChatViewInputBarView.h
//  Socket
//
//  Created by mimi on 15/4/15.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatViewInputBarView : UIView

@property(nonatomic, weak) IBOutlet UIButton* voiceChat;

@property(nonatomic, weak) IBOutlet UITextField* inputField;

@property(nonatomic, weak) IBOutlet UIButton* sendButton;

@end
