//
//  ViewController.m
//  PubChat
//
//  Created by mimi on 15/4/23.
//  Copyright (c) 2015年 mimi. All rights reserved.
//

#import "ViewController.h"

#import "SocketClient.h"

#import "NSString+formate.h"

#import "LoginApi.h"

#import "UserInfo.h"

#import "MsgLocalCache.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *startBtn;
@property (weak, nonatomic) IBOutlet UITextField *ip;
@property (weak, nonatomic) IBOutlet UITextField *port;
@property (weak, nonatomic) IBOutlet UITextField *nickName;
@property (weak, nonatomic) IBOutlet UITextView *inco;
@property (weak, nonatomic) IBOutlet UILabel *stateLabel;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _startBtn.layer.cornerRadius = CGRectGetHeight(_startBtn.frame)*0.5;
    _startBtn.layer.borderColor = [UIColor blueColor].CGColor;
    _startBtn.layer.borderWidth = 1;
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)startPubChat:(id)sender
{
    if (![SocketClient currentClient].isConnected)
    {
        NSString* sIp = _ip.text;
        if ([sIp isEqualToString:@""])
        {
            sIp = @"127.0.0.1";
        }
        NSString* sPort = _port.text;
        if ([sPort isEqualToString:@""])
        {
            sPort = @"8081";
        }
        NSUInteger value = sPort.integerValue;
        if (value > UINT16_MAX)
        {
            [_stateLabel setText:@"port is error!"];
            return;
        }
        [SocketClient currentClient].host = sIp;
        [SocketClient currentClient].port = value;
        
        self.stateLabel.text = @"connection ...";
        __weak typeof(self) blockSelf = self;
        [[SocketClient currentClient] connectToHost:^(BOOL state, NSError *error) {
            if (blockSelf)
            {
                if (state)
                {
                    blockSelf.stateLabel.text = @"connect successed!";
                    [blockSelf sendLogin];
                }
                else
                {
                    blockSelf.stateLabel.text = @"connect failed!";
                }
            }
        }];
    }
    else
    {
        [self sendLogin];
    }
}

-(void) sendLogin
{
    if ([_nickName.text isEqualToString:@""])
    {
        return;
    }
    [UserInfo currentUser].nickName = _nickName.text;
    [UserInfo currentUser].briefIntroduction = _inco.text;
    [LoginApi postLogin:_nickName.text
      briefIntroduction:_inco.text
               Response:^(LoginResponseModel *model, NSString *errMsg)
    {
        NSLog(@"recived login:%@,%@",model.msg,model.state);
        [UserInfo currentUser].userID = model.userID;
        if (model.state.integerValue > 0)
        {
            [self performSegueWithIdentifier:@"ChatListView" sender:self];
        }
    }];
}

- (IBAction)cleanMsgCache:(id)sender
{
    [[MsgLocalCache defaultCache] cleanCache];
}

@end
